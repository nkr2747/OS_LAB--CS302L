#include <iostream>
#include <bits/stdc++.h>
#include <fstream>
#include "Classes/Processor.h"
//#include "MultiCoreProcessor.h"
#include "chrono"
using namespace std;
using namespace std::chrono;

vector<Process *> parser(string location)
{
    ifstream file;
    file.open(location);
    string line = "";
    int count = 0;
    // char first ;
    vector<Process *> parsed_data;
    while (line != "<pre>")
    {
        getline(file, line);
        // cout<<line<<" ";
        count++;
        if (count > 3)
            return parsed_data;
    }
    int p_count = 1;
    while (!file.eof())
    {
        Process *temp = new Process();
        string first;
        file >> first;
        if (first == "</pre></body></html>")
        {
            break;
        }
        temp->arrival = stoi(first);
        // cout<<temp->arrival<<" ";
        int burst;
        file >> burst;

        while (burst != -1)
        {
            // cout<<burst<<" ";
            temp->bursts.push_back(burst);
            file >> burst;
        }
        // file>>burst;
        temp->p_no = p_count;
        p_count++;
        parsed_data.push_back(temp);
    }
    return parsed_data;
}

int main(int argc, char *argv[])
{
    if (argc != 3)
    {
        // cout<<argc;
        cout << "Invalid format!\nIt should be in:-\n";
        cout << "./main <scheduler-type>(FIFO/NPSJF/PSJF/RR) <test-file>";
        return 0;
    }
    char *process_file = argv[2];
    char *scheduling_algorithm = argv[1];
    vector<Process *> parsed_data = parser(process_file);
    //Processor cpu0;
    MultiCoreProcessor cpu0;
    // cpu0.RR(parsed_data,process_file,10);
    //cpu0.FIFO(parsed_data,process_file);
    //return 0;
    string algo = scheduling_algorithm;
    //display(parsed_data);
    unordered_map<string,int> mpp;
    mpp["FIFO"] = 1;
    mpp["NPSJF"] = 2;
    mpp["PSJF"] = 3;
    mpp["RR"] = 4;
    switch (mpp[algo])
    {
    case 1:{
        auto start = high_resolution_clock::now();
        cpu0.FIFO(parsed_data,process_file);
        auto stop = high_resolution_clock::now();
        auto duration = duration_cast<microseconds>(stop - start);
        cout << "Total runtime: " << duration.count() << " microseconds" << endl;
        break;
    }
    case 2:{
        auto start = high_resolution_clock::now();
        cpu0.NPSJF(parsed_data,process_file);
        auto stop = high_resolution_clock::now();
        auto duration = duration_cast<microseconds>(stop - start);
        cout << "Total runtime: " << duration.count() << " microseconds" << endl;
        break;
    }
    case 3:{
        auto start = high_resolution_clock::now();
        cpu0.PSJF(parsed_data,process_file);
        auto stop = high_resolution_clock::now();
        auto duration = duration_cast<microseconds>(stop - start);
        cout << "Total runtime: " << duration.count() << " microseconds" << endl;
        break;
    }
    case 4:{
        auto start = high_resolution_clock::now();
        cpu0.RR(parsed_data,process_file,10);
        auto stop = high_resolution_clock::now();
        auto duration = duration_cast<microseconds>(stop - start);
        cout << "Total runtime: " << duration.count() << " microseconds" << endl;
        break;
    }
    default:
        break;
    }

    return 0;
}